/* Group 27
Venkat Nalla Siddartha Reddy                2016A7PS0030P
Arnav Sailesh                               2016A7PS0054P
Gunraj Singh                                2016A7PS0085P
Aashish Singh                               2016A7PS0683P */

#ifndef TYPE_CHECKER_
#define TYPE_CHECKER_

#include "astDef.h"
#include "symbol_tableDef.h"
#include "error_handlerDef.h"

#endif
