/* Group 27
Venkat Nalla Siddartha Reddy                2016A7PS0030P
Arnav Sailesh                               2016A7PS0054P
Gunraj Singh                                2016A7PS0085P
Aashish Singh                               2016A7PS0683P */

#include "interface.h"
#include "code_gen.h"

// A global loop counter to assign unique labels to loops
int LOOP_COUNTER = 0;
// A global conditional counter to assign unique labels to conditions
int COND_COUNTER = 0;

void printLeaf(ASTNode* leafNode,FILE* f) {

    // If there is no field ID
    if(leafNode->LABEL == astId && leafNode->AST_NODE_TYPE.AST_ID.FIELD_ID == NULL)
        fprintf(f,"%s" ,leafNode->AST_NODE_TYPE.AST_ID.ID->LEXEME);
    // If there is a field id
    else if(leafNode->LABEL == astId) {
        // TODO HANDLE LATER
        fprintf(f,"REPLACEMENT");
    }
    else if(leafNode->LABEL == astNum) {
        fprintf(f,"%s" ,leafNode->AST_NODE_TYPE.AST_NUM.VALUE->LEXEME);
    }
    else if(leafNode->LABEL == astRnum) {
        fprintf(f,"%s" ,leafNode->AST_NODE_TYPE.AST_RNUM.VALUE->LEXEME);
    }
    else {
        printf("printLeaf called on a non leaf,not correct\n");
    }

}

void codeGenerationHelper(ASTNode* node, SymbolTable* st, FILE* f) {

    Label label = node->LABEL;
    switch(label) {
        case astProgram: {
            fprintf(f,"section .text\n");
            fprintf(f,"\t global _start\n");
			fprintf(f, "section .data\n");
            break;
        }
        case astFunction: {
            // No action
            break;
        }
        case astInputParams: {
            printf("Code gen cases should not involve astInputParams\n");
            break;
        }
        case astOutputParams: {
            printf("Code gen cases should not involve astOutputParams\n");
            break;
        }
        case astDatatype: {
            break;
        }
        case astStmts: {
            // Add a _main prior to handling statements
            ASTNode* trav = node->children;
            int firstFlag = 0;
            while(trav != NULL) {
                if(firstFlag == 0 && ((trav->LABEL == astAssignmentStmt) || (trav->LABEL == astConditionalStmt) || (trav->LABEL == astIterativeStmt) || (trav->LABEL == astIOStmtRead) || (trav->LABEL == astIOStmtWrite) || (trav->LABEL == astReturnStmt) )) {
                    firstFlag = 1;
                    fprintf(f,"\n\n_start:\n");
                }
                codeGenerationHelper(trav,st,f);
                trav = trav->next;
            }

            return;
            break;
        }
        case astTypeDefintion: {
            int numberFields = node->CHILDREN_COUNT;
            fprintf(f,"struc\t%s\n" ,node->AST_NODE_TYPE.AST_TYPE_DEFINITION.RECORD_ID->LEXEME+sizeof(char));

            ASTNode* trav = node->children;
            while(trav != NULL) {
                fprintf(f,"\t.%s:\tresw\t1\n",trav->AST_NODE_TYPE.AST_FIELD_DEFINITION.FIELD_ID->LEXEME);
                trav = trav->next;
            }
            fprintf(f,"endstruc\n");

            return;
            break;
        }
        case astFieldDefinition: {
            // No action
            break;
        }
        case astDeclaration: {
            ASTNode* astIdNode = node->children;
            fprintf(f,"%s:\tdw\t1\n",astIdNode->AST_NODE_TYPE.AST_ID.ID->LEXEME);
            return;
            break;
        }
        case astAssignmentStmt: {

            // TODO => HANDLE NUM RNUM AND ID
            // Evaluate arithmetic expression
            if(node->children->next->LABEL == astArithmeticExpression)
                codeGenerationHelper(node->children->next,st,f);
            // Print if leaf astNum astRnum astId
            else if(node->children->next->LABEL == astNum) {
                fprintf(f,"mov eax, %s\n" ,node->children->next->AST_NODE_TYPE.AST_NUM.VALUE->LEXEME);
            }
            else if(node->children->next->LABEL == astRnum) {
                // Case not in test cases
            }
            else if(node->children->next->LABEL == astId) {
                fprintf(f,"mov eax, %s\n" ,node->children->next->AST_NODE_TYPE.AST_ID.ID->LEXEME);
            }

            // NASM does not support direct reg to memory transfer
			// fprintf(f,"mov [");
			// printLeaf(node->children,f);
			// fprintf(f,"] , eax \n\n");

            fprintf(f,"push eax\n");
            fprintf(f,"pop word [");
			printLeaf(node->children,f);
            fprintf(f,"]\n");
            return;
            break;
        }
        case astFunCallStmt: {
            printf("Code gen cases should not involve astFunCallStmt\n");
            break;
        }
        case astIterativeStmt: {
            fprintf(f, "\nLOOP%d:\n", LOOP_COUNTER);
            codeGenerationHelper(node->children,st,f);
            fprintf(f, "\ncmp eax, 0\nje ENDLOOP%d\n", LOOP_COUNTER);
           	ASTNode* temp=node->children->next;
           	while(temp!=NULL){
            	codeGenerationHelper(temp,st,f);
               	temp=temp->next;
            }
            fprintf(f, "jmp LOOP%d\nENDLOOP%d:\n\n", LOOP_COUNTER, LOOP_COUNTER);
            LOOP_COUNTER++;

            return;
            break;
        }
        case astConditionalStmt: {
            int currentCond = COND_COUNTER;
			codeGenerationHelper(node->children,st,f);
			fprintf(f, "\ncmp eax, 0\n" );
			fprintf(f, "\nje ELSE%d\n",currentCond);
            ASTNode* trav = node->children->next;
            ASTNode* prev = trav; // Prev will store the pointer to elsePart in the end of the below loop
            // Printing the if part
            while(trav != NULL) {
			    codeGenerationHelper(trav,st,f);
                prev = trav;
                trav = trav->next;
            }
			fprintf(f, "\njmp ENDIF%d\n",currentCond);
			fprintf(f, "\nELSE%d:\n",currentCond);

            // Printing the else part
            trav = prev->children;
            while(trav != NULL) {
                codeGenerationHelper(trav,st,f);
                trav = trav->next;
            }
            break;
        }
        case astElsePart: {
            //no action
            break;
        }
        case astIOStmtRead: {
            fprintf(f,"\n\nmov eax, 3\n");    // sys read
            fprintf(f,"mov ebx, 0\n");     // stdin
            fprintf(f,"mov ecx, ");
            printLeaf(node->children,f);
            fprintf(f,"\n");    // gets read in b2
            fprintf(f,"mov edx, 1\n");     // Length of input is only 1 word in our case as integers
            fprintf(f,"int 80h\n" );        // Interrupt

            fprintf(f,"mov edx, eax\n\n"); // So that edx stores the number of bytes read
            return;
            break;
        }
        case astIOStmtWrite: {

            fprintf(f,"\n\nmov eax, 4\n");    // Set eax to write
            fprintf(f,"mov ebx, 1\n");     // stdout
            fprintf(f,"mov ecx, ");
            printLeaf(node->children,f);
            fprintf(f,"\n");    // gets Read data in the variable
            fprintf(f,"int 80h\n\n" );        // Interrupt
            return;
            break;
        }
        case astReturnStmt: {
            fprintf(f,"\n\nmov eax, 1\n");    // Set eax to write
            fprintf(f,"xor ebx, ebx\n");     // stdout
            fprintf(f,"int 80h\n\n");        // Interrupt
            break;
        }
        case astInputArgs: {
            printf("Code gen cases should not involve astInputArgs\n");
            break;
        }
        case astOutputArgs: {
            printf("Code gen cases should not involve astOutputArgs\n");
            break;
        }
        case astArithmeticExpression: {

            break;
        }
        case astBooleanExpression: {
            break;
        }
        case astId: {
            // A primitive identifier
            if(node->AST_NODE_TYPE.AST_ID.FIELD_ID == NULL) {
                // fprintf(f,"%s",node->AST_NODE_TYPE.AST_ID.ID->LEXEME);
                fprintf(f,"mov eax, [%s]\n" ,node->AST_NODE_TYPE.AST_ID.ID->LEXEME);
            }
            // Case when ID is a field of a record
            else {

            }

            break;
        }
        case astNum: {
            // Move the number to eax
            fprintf(f,"mov eax, %s\n" ,node->AST_NODE_TYPE.AST_NUM.VALUE->LEXEME);
            break;
        }
        case astRnum: {
            // Case won't be present in testcases
            break;
        }
    }

    // A general while loop which handles the children after the parent has been handled
    // In cases where the children are handled in the switch case itself, we return from the switch case itself
    ASTNode* trav = node->children;
    while(trav != NULL) {
        codeGenerationHelper(trav,st,f);
        trav = trav->next;
    }
}

// Takes as input the AST and outputs the result in an outfile
void codeGeneration(AST* ast, SymbolTable* st, FILE* f) {
    codeGenerationHelper(ast->root,st,f);
}
